EXECUTION OF .IPYNB FILE FOR FEATURE EXTRACTION
1. Using any python notebook IDE, access the Project2_WEKA.ipynb file
2. Please upload the SMS dataset and run the entire script
3. This script will output the csv file which has dataframe of all the features along with label
4. Upload this csv file in the WEKA and saveas .arff file (Saved SMS_Features.arff is already present)


EXECUTION OF ARFF INTO WEKA FOR MODEL BUILDING
1. Upload the SMS_Features.arff file into the WEKA software in the Explorer tab.
2. Once the data is uploaded, we can perform the preprocessing the classification task.